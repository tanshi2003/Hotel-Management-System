# Hotel Management System

A web application to manage a hotel. It contains the following features.

- Search rooms with check in , check out, room type.
- View all rooms, categorywise
- Add room to the wishlist
- Booking rooms
- Sign up, Sign in, profile update.
- Booking history.
- 
**Note:** this project can extend for further use. The default django admin pannel used to handle all the admin works withe permission

## Used Technology

- Backend: Django
- Frontend: Booststrap
